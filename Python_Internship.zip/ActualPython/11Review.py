import mysql.connector as mycon

bookcode=input("Enter the Book Code : ")
review=input("Enter the Reviews : ")

con=mycon.connect(host='bol5h9em7wu9xcbbmhj5-mysql.services.clever-cloud.com',user='u1tirjgc9elbs2nl',password='37reOOTfvBjYeFJgr99w',database='bol5h9em7wu9xcbbmhj5')
curs=con.cursor()

curs.execute("select bookcode from books where bookcode='%s'" %bookcode)
data=curs.fetchone()

if bookcode in data:
        curs.execute("update books set review='%s' where bookcode='%s';" %(review,bookcode))
        con.commit()
        print("Reviews added to the record...")

con.close()