import mysql.connector as mycon

con=mycon.connect(host='bol5h9em7wu9xcbbmhj5-mysql.services.clever-cloud.com',user='u1tirjgc9elbs2nl',password='37reOOTfvBjYeFJgr99w',database='bol5h9em7wu9xcbbmhj5')
curs=con.cursor()

author=input("Enter the name of Author : ")
publication=input("Enter the name of Publication : ")

curs.execute("select * from books where author='%s' and publication='%s';" %(author,publication))
rec=curs.fetchone()


try:
    print("-------------------------------------")
    print("The bookname is :- %s" %rec[1])
    
except:
    print("book not found")

con.close()