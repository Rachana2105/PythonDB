import mysql.connector as mycon

con=mycon.connect(host='bol5h9em7wu9xcbbmhj5-mysql.services.clever-cloud.com',user='u1tirjgc9elbs2nl',password='37reOOTfvBjYeFJgr99w',database='bol5h9em7wu9xcbbmhj5')
curs=con.cursor()

curs.execute("select * from books")
data=curs.fetchall()

print(data)

con.close()