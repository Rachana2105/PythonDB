import mysql.connector as mycon

con=mycon.connect(host='bol5h9em7wu9xcbbmhj5-mysql.services.clever-cloud.com',user='u1tirjgc9elbs2nl',password='37reOOTfvBjYeFJgr99w',database='bol5h9em7wu9xcbbmhj5')
curs=con.cursor()

bookcode=input("Enter the Book Code : ")

curs.execute("select bookcode,bookname,category,author,publication,edition,price from books where bookcode='%s'" %bookcode)
rec=curs.fetchone()


try:

  print("Book Code : %s" %rec[0])
  print("Book Name : %s" %rec[1])
  print("Category : %s" %rec[2])
  print("Author : %s" %rec[3])
  print("Publication : %s" %rec[4])
  print("Edition: %d" %rec[5])
  print("Price : %d" %rec[6])

except:
     print("not found")
con.close()