import mysql.connector as mycon

con=mycon.connect(host='bol5h9em7wu9xcbbmhj5-mysql.services.clever-cloud.com',user='u1tirjgc9elbs2nl',password='37reOOTfvBjYeFJgr99w',database='bol5h9em7wu9xcbbmhj5')
curs=con.cursor()

category=input("Enter the Book Category : ")

curs.execute("select bookcode,bookname,category,author,publication,edition,price from books where category='%s'" %category)
data=curs.fetchall()

for rec in data:

  print("Book Code : %s" %rec[0])
  print("Book Name : %s" %rec[1])
  print("Category : %s" %rec[2])
  print("Author : %s" %rec[3])
  print("Publication : %s" %rec[4])
  print("Edition: %d" %rec[5])
  print("Price : %d" %rec[6])

con.close()