import mysql.connector as mycon

bookcode=input("Enter the Book Code : ")
price=int(input("Enter the Book updated price : "))

con=mycon.connect(host='bol5h9em7wu9xcbbmhj5-mysql.services.clever-cloud.com',user='u1tirjgc9elbs2nl',password='37reOOTfvBjYeFJgr99w',database='bol5h9em7wu9xcbbmhj5')
curs=con.cursor()

curs.execute("select bookcode from books where bookcode='%s'" %bookcode)
data=curs.fetchone()

try:
    if bookcode in data:
        curs.execute("update books set price=%d where bookcode='%s';" %(price,bookcode))
        con.commit()
        print("Price Updated Successful...")

except:
    print("Book does not exist!")
con.close()            
